/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package vicky;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

/**
 *
 * @author user
 */
@WebService()
public class NewWebService {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "add")
    public Integer add(@WebParam(name = "a")
    final int a, @WebParam(name = "b")
    final int b) {
        //TODO write your implementation code here:
        return a+b;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "sub")
    public Integer sub(@WebParam(name = "a")
    final int a, @WebParam(name = "b")
    final int b) {
        //TODO write your implementation code here:
        return a-b;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "mul")
    public Integer mul(@WebParam(name = "a")
    final int a, @WebParam(name = "b")
    final int b) {
        //TODO write your implementation code here:
        return a*b;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "div")
    public Integer div(@WebParam(name = "a")
    final int a, @WebParam(name = "b")
    final int b) {
        //TODO write your implementation code here:
        if(b==0){
            return -1;
        }
        return a/b;
    }

}

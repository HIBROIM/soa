/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.jd;

import java.sql.*;
import java.util.Vector;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

/**
 *
 * @author user
 */
@WebService()
public class New {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "getId")
    public Vector getId(@WebParam(name = "id")
    final int id) throws Exception {
        Vector v = new Vector();
        Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
        Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/college;create=true;user=root;password=root");
        Statement stmt = conn.createStatement();
        String query = "SELECT * FROM COLLEGE WHERE ID = " + id;
        ResultSet rs = stmt.executeQuery(query);
        if(rs != null){
            rs.next();
            v.addElement(rs.getString("name"));
            v.addElement(rs.getString("department"));
        }
        else{
            v.addElement("NULL");
        }
        return v;
    }
}

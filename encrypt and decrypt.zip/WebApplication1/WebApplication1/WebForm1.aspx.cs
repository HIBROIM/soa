﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            WebService1 ws = new WebService1();
            String a = TextBox1.Text;
            string val = ws.encrypt(a);
            TextBox2.Text = val;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            WebService1 ws = new WebService1();
            String a = TextBox3.Text;
            string val = ws.decrypt(a);
            TextBox4.Text = val;
        }
    }
}

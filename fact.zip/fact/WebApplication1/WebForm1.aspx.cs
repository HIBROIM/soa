﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
            protected void Page_Load(object sender, EventArgs e)
            {
                
            }

        protected void Button1_Click(object sender, EventArgs e)
        {
            WebService1 ws = new WebService1();
                string a = TextBox1.Text;
                int al = int.Parse(a);
                int val = ws.factorial(al);
                TextBox2.Text = val.ToString();
        }

        

        protected void Button2_Click(object sender, EventArgs e)
        {
            WebService1 ws = new WebService1();
            string a = TextBox3.Text;
            int al = int.Parse(a);
            string val = ws.fibonacci(al);
            TextBox4.Text = val;
        }
    }
}

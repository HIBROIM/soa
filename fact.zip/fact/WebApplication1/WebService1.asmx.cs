﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Linq;

namespace WebApplication1
{
    /// <summary>
    /// Summary description for WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {

        [WebMethod]
        public int factorial(int a)
        {
            if (a == 0)
            {
                return 1;
            }
            return a * factorial(a - 1);
        }
        [WebMethod]
        public string fibonacci(int a)
        {
            int n1 = 0, n2 = 1, n3 = 0;
            String s = n1 + "," + n2;
            if (a < 2)
            {
                return "0";
            }
            for (int i = 2; i <= a; i++)
            {
                n3 = n1 + n2;
                s +=  "," + n3;
                n1 = n2;
                n2 = n3;
            }
            return s;
        }
    }
}

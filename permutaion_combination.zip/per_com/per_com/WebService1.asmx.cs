﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Linq;

namespace per_com
{
    /// <summary>
    /// Summary description for WebService1
    /// </summary>
    [WebService(Namespace = "http://localhost:55042/WebService1.asmx?WSDL")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {

        [WebMethod]
        public int factorial(int a)
        {
            if (a == 0)
                return 1;
            return a * factorial(a - 1);
        }

        [WebMethod]
        public int permutation(int n, int r)
        {
            int p = factorial(n);
            int diff = factorial(n - r);
            return (p / diff);
        }

        [WebMethod]
        public int combination(int n, int r)
        {
            int p = factorial(n);
            int diff = factorial(n - r);
            int q = factorial(r);
            return (p / (q * diff));
        }
    }
}
